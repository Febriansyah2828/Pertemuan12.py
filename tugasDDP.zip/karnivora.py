from animal import Animal

class Karnivora(Animal):
    def __init__(self, nama, makanan, hidup, berkembang_biak, berburu_mangsa, gigi_taring):
        super().__init__(nama, makanan, hidup, berkembang_biak)
        self.berburu_mangsa = berburu_mangsa
        self.gigi_taring = gigi_taring

    def info_karnivora(self):
         super().info_animal()
         print("berburu mangsa \t\t\t : ", self.berburu_mangsa,
               "\ngigi taring \t\t\t : ", self.gigi_taring)
         
macan = Karnivora("macan", "daging", "darat", "melahirkan", "terkam", "berbulu")
macan.info_karnivora()
print('=============================================================================')

#Karnivora2

class Karnivora(Animal):
    def __init__(self, nama, makanan, hidup, berkembang_biak, berburu_mangsa, gigi_taring):
        super().__init__(nama, makanan, hidup, berkembang_biak)
        self.berburu_mangsa = berburu_mangsa
        self.gigi_taring = gigi_taring

    def info_karnivora(self):
         super().info_animal()
         print("berburu mangsa \t\t\t : ", self.berburu_mangsa,
               "\ngigi taring \t\t\t : ", self.gigi_taring)
         
singa = Karnivora("singa", "daging", "darat", "melahirkan", "terkam", "berbulu")
singa.info_karnivora()
print('=============================================================================')

#Karnivora3


class Karnivora(Animal):
    def __init__(self, nama, makanan, hidup, berkembang_biak, berburu_mangsa, gigi_taring):
        super().__init__(nama, makanan, hidup, berkembang_biak)
        self.berburu_mangsa = berburu_mangsa
        self.gigi_taring = gigi_taring

    def info_karnivora(self):
         super().info_animal()
         print("berburu mangsa \t\t\t : ", self.berburu_mangsa,
               "\ngigi taring \t\t\t : ", self.gigi_taring)
         
harimau = Karnivora("harimau", "daging", "darat", "melahirkan", "terkam", "berbulu")
harimau.info_karnivora()