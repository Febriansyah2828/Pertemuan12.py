from animal import Animal

class Mamalia(Animal):
    def __init__(self, nama, makanan, hidup, berkembang_biak, ukuran_tubuh, jenis_kulit):
        super().__init__(nama, makanan, hidup, berkembang_biak)
        self.ukuran_tubuh = ukuran_tubuh
        self.jenis_kulit = jenis_kulit

    def info_mamalia(self):
         super().info_animal()
         print("ukuran_tubuh \t\t\t : ", self.ukuran_tubuh,
               "\nJenis kulit \t\t\t : ", self.jenis_kulit)
         
gajah = Mamalia("gajah", "tumbuh-tumbuhan", "darat", "melahirkan", "sangat besar", "sedikit berbulu")
gajah.info_mamalia()
print("=============================================================================================")

#mamalia2

class Mamalia(Animal):
    def __init__(self, nama, makanan, hidup, berkembang_biak, ukuran_tubuh, jenis_kulit):
        super().__init__(nama, makanan, hidup, berkembang_biak)
        self.ukuran_tubuh = ukuran_tubuh
        self.jenis_kulit = jenis_kulit

    def info_mamalia(self):
         super().info_animal()
         print("ukuran_tubuh \t\t\t : ", self.ukuran_tubuh,
               "\nJenis kulit \t\t\t : ", self.jenis_kulit)

kucing = Mamalia("kucing", "ikan", "darat", "melahirkan", "kecil", "berbulu")
kucing.info_mamalia()




print("=============================================================================================")

#mamalia3


class Mamalia(Animal):
    def __init__(self, nama, makanan, hidup, berkembang_biak, ukuran_tubuh, jenis_kulit):
        super().__init__(nama, makanan, hidup, berkembang_biak)
        self.ukuran_tubuh = ukuran_tubuh
        self.jenis_kulit = jenis_kulit

    def info_mamalia(self):
         super().info_animal()
         print("ukuran_tubuh \t\t\t : ", self.ukuran_tubuh,
               "\nJenis kulit \t\t\t : ", self.jenis_kulit)
         
sapi = Mamalia("sapi", "tumbuh-tumbuhan", "darat", "melahirkan", "sangat besar", "berbulu")
sapi.info_mamalia()