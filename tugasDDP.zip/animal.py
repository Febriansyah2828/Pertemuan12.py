#Buat class animal sebagai parent class. class animal mempunyai properti 4 properti (name, makanan, hidup, berkembang biak)

class Animal:
    def __init__(self, nama, makanan, hidup, berkembang_biak):
        self.nama = nama
        self.makanan = makanan
        self.hidup = hidup
        self.berkembang_biak = berkembang_biak

    def info_animal(self):
        print(f"Nama Hewan \t\t\t : ", self.nama,
        "\nMakanan \t\t\t : ", self.makanan,
        "\nHidup \t\t\t\t : ", self.hidup,
        "\nBerkembang_biak \t\t : ", self.berkembang_biak)

#hewan = Animal("Kucing Garong", "Cimol", "Udara", "Bertelur")
#hewan.info_animal()





