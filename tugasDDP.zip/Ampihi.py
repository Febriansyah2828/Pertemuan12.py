from animal import Animal

# setiap class child itu memiliki 2 properti dan method
class Amphibi(Animal):
    def __init__(self, nama, makanan, hidup, berkembang_biak, jenis_air, bernapas ):
        super().__init__(nama, makanan, hidup, berkembang_biak)
        self.jenis_air = jenis_air
        self.bernapas = bernapas

    def info_Amphibi(self):
        super().info_animal()
        print("Jenis air \t\t\t : ", self.jenis_air,
            "\nBernapas \t\t\t : ", self.bernapas)

Amphibi = Amphibi("katak", "serangga", "dua alam", "bertelur", "air tawar", "kulit dan paru-paru" )
Amphibi.info_Amphibi()
print('======================================================================================')

#amphibi2

class Amphibi(Animal):
    def __init__(self, nama, makanan, hidup, berkembang_biak, jenis_air, bernapas ):
        super().__init__(nama, makanan, hidup, berkembang_biak)
        self.jenis_air = jenis_air
        self.bernapas = bernapas

    def info_Amphibi(self):
        super().info_animal()
        print("Jenis air \t\t\t : ", self.jenis_air,
            "\nBernapas \t\t\t : ", self.bernapas)

Amphibi = Amphibi("biawak", "serangga", "dua alam", "bertelur", "sungai", "penglihatan dan penciuman" )
Amphibi.info_Amphibi()
print('=======================================================================================')

#amphibi3


class Amphibi(Animal):
    def __init__(self, nama, makanan, hidup, berkembang_biak, jenis_air, bernapas ):
        super().__init__(nama, makanan, hidup, berkembang_biak)
        self.jenis_air = jenis_air
        self.bernapas = bernapas

    def info_Amphibi(self):
        super().info_animal()
        print("Jenis air \t\t\t : ", self.jenis_air,
            "\nBernapas \t\t\t : ", self.bernapas)

Amphibi = Amphibi("salamander", "serangga", "dua alam", "bertelur", "air tawar", "kulit dan paru-paru" )
Amphibi.info_Amphibi()